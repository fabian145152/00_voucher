<?php
// parametros: host,user,password,database
$con = new mysqli("localhost","root","","importex1");
?>